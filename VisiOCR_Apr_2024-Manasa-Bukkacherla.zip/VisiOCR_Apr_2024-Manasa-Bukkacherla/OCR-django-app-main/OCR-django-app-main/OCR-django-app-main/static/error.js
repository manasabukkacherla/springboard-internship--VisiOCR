setTimeout(function () {
    const modal = document.getElementById("error-modal");
    // hide modal after 3 seconds
    modal.style.display = "none";
}, 2800);